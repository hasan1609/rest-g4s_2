<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\go4-sumbergedang\rest-g4s\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>